<?php
session_start();
session_destroy();
?>
<script>
    
    location.href = "main.html";
</script>